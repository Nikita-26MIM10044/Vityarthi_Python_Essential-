# Problem Statement

Manual tracking of student marks (spreadsheets, paper registers) is
error-prone, hard to search, and gives students no direct way to check
their own results without going through an administrator. There is no
single lightweight tool for a small course/class to record marks, compute
grades consistently, and let both staff and students access the results
relevant to them.

## Scope
This project implements a desktop application that:
- Allows an admin to register students and record/update their subject marks
- Automatically computes total score, percentage, letter grade, and
  pass/fail status using a fixed grading scale
- Allows students to log in and view only their own result
- Provides the admin with class-level statistics (average, topper)

Out of scope: multi-class/multi-semester tracking, persistent storage across
sessions, network/multi-user concurrent access, and password security beyond
basic authentication (all noted as future enhancements).

## Target Users
- **Admin / Teacher** — responsible for maintaining student records and marks
- **Student** — views their own academic performance

## High-Level Features
- Role-based login (Admin / Student)
- Add, update, and delete student records
- Enter and update subject-wise marks with validation
- Automatic grade and pass/fail computation
- Class-wide result table and statistics for admin
- Individual result view for students
