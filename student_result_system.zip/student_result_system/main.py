"""
main.py
Entry point for the command-line interface.
Loops: Login -> Admin/Student menu -> Logout -> back to Login, until Exit.

Run with:  python main.py
"""

from core.school_system import SchoolSystem
from cli.login import run_login
from cli.admin_menu import run_admin_menu
from cli.student_menu import run_student_menu


def main():
    print("=====================================================")
    print(" Student Result & Grade Management System (CLI)")
    print("=====================================================")

    school_system = SchoolSystem()

    while True:
        role, user = run_login(school_system)

        if role is None:
            print("Goodbye!")
            break
        elif role == "admin":
            run_admin_menu(school_system)
        elif role == "student":
            run_student_menu(user)


if __name__ == "__main__":
    main()
