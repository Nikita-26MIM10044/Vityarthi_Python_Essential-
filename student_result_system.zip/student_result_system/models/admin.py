"""
admin.py
Admin class (inherits Person). No extra state needed beyond Person,
but kept as its own class for clear role separation and future extension
(e.g. permission levels).
"""

from models.person import Person


class Admin(Person):
    def __init__(self, admin_id: str, name: str, password: str):
        super().__init__(admin_id, name, password)
