"""
person.py
Base class for anyone who can log into the system.
Demonstrates: OOP (base class), encapsulation.
"""


class Person:
    """Base class representing any user of the system."""

    def __init__(self, user_id: str, name: str, password: str):
        self._user_id = user_id      # protected attribute (encapsulation)
        self._name = name
        self._password = password

    # ---- Getters (encapsulation) ----
    def get_id(self) -> str:
        return self._user_id

    def get_name(self) -> str:
        return self._name

    def check_password(self, attempt: str) -> bool:
        return self._password == attempt

    def __str__(self):
        return f"{self.__class__.__name__}({self._user_id}, {self._name})"
