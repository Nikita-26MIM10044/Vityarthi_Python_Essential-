"""
student.py
Student class (inherits Person).
Demonstrates: inheritance, array/list data structure (marks list).
"""

from typing import List
from models.person import Person
from models.result import Mark, Result


class Student(Person):
    """A student who owns a roll number and a list of subject marks."""

    def __init__(self, roll_no: str, name: str, password: str):
        super().__init__(roll_no, name, password)
        self.roll_no = roll_no
        self.marks: List[Mark] = []   # array-like structure of Mark objects

    def add_or_update_mark(self, subject: str, score: float, max_score: float = 100.0):
        # Search list for existing subject entry, update if found (else append)
        for m in self.marks:
            if m.subject.lower() == subject.lower():
                m.score = float(score)
                m.max_score = float(max_score)
                return
        self.marks.append(Mark(subject, score, max_score))

    def remove_mark(self, subject: str) -> bool:
        for m in self.marks:
            if m.subject.lower() == subject.lower():
                self.marks.remove(m)
                return True
        return False

    def get_result(self) -> Result:
        return Result(self.marks)

    def __str__(self):
        return f"Student({self.roll_no}, {self._name}, subjects={len(self.marks)})"
