"""
result.py
Mark and Result classes.
Demonstrates: core data structures (list/dict of marks), control flow,
type conversion, operators & precedence (grade computation).
"""

from typing import List, Dict


class Mark:
    """Represents a single subject's score for a student."""

    def __init__(self, subject: str, score: float, max_score: float = 100.0):
        self.subject = subject
        self.score = float(score)          # explicit type conversion
        self.max_score = float(max_score)

    def percentage(self) -> float:
        # operator precedence: division happens before multiplication is applied correctly
        return (self.score / self.max_score) * 100


class Result:
    """
    Computes overall result (total, percentage, grade, pass/fail)
    from a list of Mark objects belonging to one student.
    """

    # Grade boundaries (used with control flow / if-elif chain)
    GRADE_TABLE = [
        (90, "A+"),
        (80, "A"),
        (70, "B"),
        (60, "C"),
        (50, "D"),
        (40, "E"),
        (0, "F"),
    ]
    PASS_THRESHOLD = 40.0

    def __init__(self, marks: List[Mark]):
        self.marks: List[Mark] = marks

    def total_score(self) -> float:
        return sum(m.score for m in self.marks)

    def total_max(self) -> float:
        return sum(m.max_score for m in self.marks)

    def overall_percentage(self) -> float:
        total_max = self.total_max()
        if total_max == 0:
            return 0.0
        return (self.total_score() / total_max) * 100

    def grade(self) -> str:
        pct = self.overall_percentage()
        for boundary, letter in self.GRADE_TABLE:
            if pct >= boundary:
                return letter
        return "F"

    def status(self) -> str:
        return "PASS" if self.overall_percentage() >= self.PASS_THRESHOLD else "FAIL"

    def as_dict(self) -> Dict:
        """Used by the GUI to display a clean summary."""
        return {
            "subjects": [(m.subject, m.score, m.max_score) for m in self.marks],
            "total": self.total_score(),
            "out_of": self.total_max(),
            "percentage": round(self.overall_percentage(), 2),
            "grade": self.grade(),
            "status": self.status(),
        }
