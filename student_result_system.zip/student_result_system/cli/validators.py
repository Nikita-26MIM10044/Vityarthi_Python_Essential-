"""
validators.py
Reusable input validation functions used across the CLI.
Demonstrates: string operations, control flow, error handling design.

Each function returns (is_valid: bool, error_message: str).
"""

import re

NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z .'-]*$")
ROLL_PATTERN = re.compile(r"^[A-Za-z0-9]+$")


def validate_name(name: str):
    if not name:
        return False, "Name cannot be empty."
    if not NAME_PATTERN.match(name):
        return False, "Name must contain only letters (and spaces/hyphens/apostrophes), and cannot start with a digit."
    return True, ""


def validate_roll_no(roll_no: str):
    if not roll_no:
        return False, "Roll number cannot be empty."
    if not ROLL_PATTERN.match(roll_no):
        return False, "Roll number must be alphanumeric (letters and digits only, no spaces or symbols)."
    return True, ""


def validate_password(password: str):
    if not password:
        return False, "Password cannot be empty."
    if len(password) < 4:
        return False, "Password must be at least 4 characters long."
    return True, ""


def validate_subject(subject: str):
    if not subject:
        return False, "Subject cannot be empty."
    if subject.isdigit():
        return False, "Subject name cannot be just a number."
    if not any(ch.isalpha() for ch in subject):
        return False, "Subject name must contain at least one letter."
    return True, ""


def validate_id(user_id: str, label: str = "ID"):
    """Generic validator for login IDs (admin ID, roll no) — alphanumeric, non-empty."""
    if not user_id:
        return False, f"{label} cannot be empty."
    if not ROLL_PATTERN.match(user_id):
        return False, f"{label} must be alphanumeric (letters and digits only, no spaces or symbols)."
    return True, ""


def validate_yes_no(response: str):
    if response not in ("y", "n"):
        return False, "Please enter 'y' or 'n'."
    return True, ""


def validate_menu_choice(choice: str, valid_options):
    """valid_options: iterable of valid string choices, e.g. ('1','2','3')."""
    if choice not in valid_options:
        return False, f"Invalid option. Please choose one of: {', '.join(valid_options)}."
    return True, ""


def validate_score(score_raw: str, max_raw: str):
    try:
        score = float(score_raw)
        max_score = float(max_raw)
    except ValueError:
        return False, "Score and Max must be valid numbers.", None, None

    if max_score <= 0:
        return False, "Max score must be greater than 0.", None, None
    if score < 0:
        return False, "Score cannot be negative.", None, None
    if score > max_score:
        return False, "Score cannot be greater than Max score.", None, None

    return True, "", score, max_score
