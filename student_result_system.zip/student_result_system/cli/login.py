"""
login.py
Handles role selection and login for the CLI.
"""

from core.school_system import SchoolSystem
from cli.validators import validate_id, validate_password, validate_menu_choice


def run_login(school_system: SchoolSystem):
    """
    Returns a tuple: ("admin", admin_obj) or ("student", student_obj) on success,
    or (None, None) if the user chooses to exit.
    """
    while True:
        print("\n===== LOGIN =====")
        print("1. Login as Admin")
        print("2. Login as Student")
        print("3. Exit")
        choice = input("Choose an option (1-3): ").strip()

        ok, msg = validate_menu_choice(choice, ("1", "2", "3"))
        if not ok:
            print(f"Error: {msg}")
            continue

        if choice == "1":
            admin_id = input("Admin ID: ").strip()
            password = input("Password: ").strip()

            ok, msg = validate_id(admin_id, "Admin ID")
            if not ok:
                print(f"Error: {msg}")
                continue
            ok, msg = validate_password(password)
            if not ok:
                print(f"Error: {msg}")
                continue

            admin = school_system.login_admin(admin_id, password)
            if admin:
                print(f"Welcome, {admin.get_name()}!")
                return "admin", admin
            print("Invalid admin ID or password.")

        elif choice == "2":
            roll = input("Roll No: ").strip()
            password = input("Password: ").strip()

            ok, msg = validate_id(roll, "Roll No")
            if not ok:
                print(f"Error: {msg}")
                continue
            ok, msg = validate_password(password)
            if not ok:
                print(f"Error: {msg}")
                continue

            student = school_system.login_student(roll, password)
            if student:
                print(f"Welcome, {student.get_name()}!")
                return "student", student
            print("Invalid roll number or password.")

        else:  # choice == "3"
            return None, None
