"""
admin_menu.py
Text-based menu for the Admin role.
Demonstrates: input/output operations, control flow (loops/if-elif),
type conversion, error handling.
"""

from core.school_system import SchoolSystem
from cli.validators import (
    validate_name, validate_roll_no, validate_password, validate_subject,
    validate_score, validate_yes_no, validate_menu_choice,
)


def run_admin_menu(school_system: SchoolSystem):
    valid_options = ("1", "2", "3", "4", "5", "6")
    while True:
        print("\n----- ADMIN MENU -----")
        print("1. Add Student")
        print("2. Enter / Update Marks")
        print("3. View All Students")
        print("4. View Class Statistics")
        print("5. Delete Student")
        print("6. Logout")
        choice = input("Choose an option (1-6): ").strip()

        ok, msg = validate_menu_choice(choice, valid_options)
        if not ok:
            print(f"Error: {msg}")
            continue

        if choice == "1":
            _add_student(school_system)
        elif choice == "2":
            _enter_marks(school_system)
        elif choice == "3":
            _view_all_students(school_system)
        elif choice == "4":
            _view_stats(school_system)
        elif choice == "5":
            _delete_student(school_system)
        elif choice == "6":
            print("Logging out...")
            break


def _add_student(school_system: SchoolSystem):
    print("\n-- Add New Student --")
    roll = input("Roll No: ").strip()
    name = input("Name: ").strip()
    password = input("Password: ").strip()

    ok, msg = validate_roll_no(roll)
    if not ok:
        print(f"Error: {msg}")
        return

    ok, msg = validate_name(name)
    if not ok:
        print(f"Error: {msg}")
        return

    ok, msg = validate_password(password)
    if not ok:
        print(f"Error: {msg}")
        return

    try:
        school_system.add_student(roll, name, password)
        print(f"Student '{name}' added successfully.")
    except ValueError as e:
        print(f"Error: {e}")


def _enter_marks(school_system: SchoolSystem):
    print("\n-- Enter / Update Marks --")
    roll = input("Roll No: ").strip()

    ok, msg = validate_roll_no(roll)
    if not ok:
        print(f"Error: {msg}")
        return

    student = school_system.get_student(roll)
    if not student:
        print(f"Error: No student found with roll no '{roll}'.")
        return

    subject = input("Subject: ").strip()
    ok, msg = validate_subject(subject)
    if not ok:
        print(f"Error: {msg}")
        return

    score_raw = input("Score: ").strip()
    max_raw = input("Max Score (press Enter for 100): ").strip() or "100"

    ok, msg, score, max_score = validate_score(score_raw, max_raw)
    if not ok:
        print(f"Error: {msg}")
        return

    student.add_or_update_mark(subject, score, max_score)
    print(f"Saved: {subject} = {score}/{max_score} for {student.get_name()}.")


def _view_all_students(school_system: SchoolSystem):
    print("\n-- All Students --")
    students = school_system.list_students()
    if not students:
        print("No students registered yet.")
        return

    header = f"{'Roll No':<10}{'Name':<20}{'Subjects':<10}{'%':<8}{'Grade':<7}{'Status':<7}"
    print(header)
    print("-" * len(header))
    for student in students:
        result = student.get_result().as_dict()
        print(f"{student.roll_no:<10}{student.get_name():<20}{len(student.marks):<10}"
              f"{result['percentage']:<8}{result['grade']:<7}{result['status']:<7}")


def _view_stats(school_system: SchoolSystem):
    print("\n-- Class Statistics --")
    avg = school_system.class_average()
    topper = school_system.topper()
    print(f"Class Average: {avg}%")
    print(f"Topper: {topper.get_name() if topper else 'N/A'}")


def _delete_student(school_system: SchoolSystem):
    print("\n-- Delete Student --")
    roll = input("Roll No to delete: ").strip()

    ok, msg = validate_roll_no(roll)
    if not ok:
        print(f"Error: {msg}")
        return

    confirm = input(f"Are you sure you want to delete '{roll}'? (y/n): ").strip().lower()
    ok, msg = validate_yes_no(confirm)
    if not ok:
        print(f"Error: {msg}")
        return

    if confirm == "y":
        if school_system.delete_student(roll):
            print("Student deleted.")
        else:
            print(f"Error: No student found with roll no '{roll}'.")
    else:
        print("Cancelled.")
