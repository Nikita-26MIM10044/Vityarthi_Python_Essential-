"""
student_menu.py
Text-based menu for the Student role — read-only view of own result.
"""

from models.student import Student
from cli.validators import validate_menu_choice


def run_student_menu(student: Student):
    valid_options = ("1", "2")
    while True:
        print(f"\n----- STUDENT MENU ({student.get_name()}) -----")
        print("1. View My Result")
        print("2. Logout")
        choice = input("Choose an option (1-2): ").strip()

        ok, msg = validate_menu_choice(choice, valid_options)
        if not ok:
            print(f"Error: {msg}")
            continue

        if choice == "1":
            _view_result(student)
        else:  # choice == "2"
            print("Logging out...")
            break


def _view_result(student: Student):
    result = student.get_result().as_dict()
    print(f"\n-- Result for {student.get_name()} ({student.roll_no}) --")

    if not result["subjects"]:
        print("No marks entered yet.")
        return

    header = f"{'Subject':<20}{'Score':<10}{'Max':<10}"
    print(header)
    print("-" * len(header))
    for subject, score, max_score in result["subjects"]:
        print(f"{subject:<20}{score:<10}{max_score:<10}")

    print(f"\nTotal: {result['total']} / {result['out_of']}")
    print(f"Percentage: {result['percentage']}%")
    print(f"Grade: {result['grade']}")
    print(f"Status: {result['status']}")
