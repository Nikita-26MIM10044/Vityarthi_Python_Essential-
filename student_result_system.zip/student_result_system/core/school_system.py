"""
school_system.py
Central in-memory data manager. Keeps GUI code decoupled from data logic
(maintainability / modularity). Uses dicts keyed by ID for efficient lookup.
"""

from typing import Dict, Optional, List
from models.student import Student
from models.admin import Admin


class SchoolSystem:
    """
    Holds all students and admins in memory (no persistence, as scoped).
    Provides CRUD-style operations and login/authentication.
    """

    def __init__(self):
        self.students: Dict[str, Student] = {}   # roll_no -> Student
        self.admins: Dict[str, Admin] = {}        # admin_id -> Admin
        self._seed_data()

    # ---------- Seed / demo data ----------
    def _seed_data(self):
        self.add_admin("admin1", "Admin User", "admin123")

        s1 = self.add_student("S001", "Aarav Sharma", "pass123")
        s1.add_or_update_mark("Mathematics", 88)
        s1.add_or_update_mark("Physics", 76)
        s1.add_or_update_mark("Python Programming", 92)

        s2 = self.add_student("S002", "Diya Patel", "pass123")
        s2.add_or_update_mark("Mathematics", 45)
        s2.add_or_update_mark("Physics", 38)
        s2.add_or_update_mark("Python Programming", 60)

    # ---------- Admin management ----------
    def add_admin(self, admin_id: str, name: str, password: str) -> Admin:
        admin = Admin(admin_id, name, password)
        self.admins[admin_id] = admin
        return admin

    # ---------- Student CRUD ----------
    def add_student(self, roll_no: str, name: str, password: str) -> Student:
        if roll_no in self.students:
            raise ValueError(f"Student with roll no '{roll_no}' already exists.")
        student = Student(roll_no, name, password)
        self.students[roll_no] = student
        return student

    def get_student(self, roll_no: str) -> Optional[Student]:
        return self.students.get(roll_no)

    def delete_student(self, roll_no: str) -> bool:
        if roll_no in self.students:
            del self.students[roll_no]
            return True
        return False

    def list_students(self) -> List[Student]:
        return list(self.students.values())

    # ---------- Authentication ----------
    def login_admin(self, admin_id: str, password: str) -> Optional[Admin]:
        admin = self.admins.get(admin_id)
        if admin and admin.check_password(password):
            return admin
        return None

    def login_student(self, roll_no: str, password: str) -> Optional[Student]:
        student = self.students.get(roll_no)
        if student and student.check_password(password):
            return student
        return None

    # ---------- Class-wide stats (for admin reports) ----------
    def class_average(self) -> float:
        if not self.students:
            return 0.0
        percentages = [s.get_result().overall_percentage() for s in self.students.values()]
        return round(sum(percentages) / len(percentages), 2)

    def topper(self) -> Optional[Student]:
        if not self.students:
            return None
        return max(self.students.values(), key=lambda s: s.get_result().overall_percentage())
